package com.example.commande_pc.entity;

public enum AllowedCombinaison {
    ONLY_SAME,
    MIXT_ALLOWED,
    ONLY_DIFFRERENT
}
