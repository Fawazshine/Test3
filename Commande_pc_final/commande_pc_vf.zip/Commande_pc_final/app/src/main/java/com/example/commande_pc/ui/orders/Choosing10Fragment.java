package com.example.commande_pc.ui.orders;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.commande_pc.databinding.ChoosingItems10Binding;
import com.example.commande_pc.databinding.ChoosingItems9Binding;

public class Choosing10Fragment extends OrderChoiceFragment {
    public int getPosition() {
        return 8;
    }
}
